﻿Imports MySql.Data.MySqlClient
Public Class Encuesta

    'Tarea de Manuel Diu

    Private Sub btn_connect_Click(sender As Object, e As EventArgs) Handles btn_connect.Click

        Dim conexion As MySqlConnection
        conexion = New MySqlConnection
        Dim cmd As New MySqlCommand

        conexion.ConnectionString = "server=localhost; database=encuesta; Uid=root; Pwd=;"

        Try
            conexion.Open()
            MsgBox("Conexión Establecida con el servidor de bases de datos")
            cmd.Connection = conexion
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

        If (txb_nombre.Text = "" Or txb_apellido.Text = "" Or cmbx_serie.SelectedItem = "") Then
            MsgBox("Verifique que haya completado todos los campos.")
        Else
            Try
                cmd.CommandText = "INSERT INTO encuesta_series(id,nombre,apellido,serie_favorita) VALUES('',@nombre,@apellido,@serie_favorita)"
                cmd.Prepare()

                cmd.Parameters.AddWithValue("@nombre", txb_nombre.Text)
                cmd.Parameters.AddWithValue("@apellido", txb_apellido.Text)
                cmd.Parameters.AddWithValue("@serie_favorita", cmbx_serie.SelectedItem)
                cmd.ExecuteNonQuery()
                MsgBox("Los datos se guardaron correctamente.")
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If
    End Sub
End Class